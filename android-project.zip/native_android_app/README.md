# Stealth APK Forge - Aplicativo Android

Versão nativa do aplicativo Stealth APK Forge, projetada para instalação forçada de APKs em dispositivos Android.

## Recursos Principais

- **Instalação Forçada**: Tenta instalar APKs sem interação do usuário
- **Ativação Automática**: Habilita fontes desconhecidas automaticamente 
- **Suporte a Root**: Utiliza privilégios root se disponíveis para instalação silenciosa
- **Interface Elegante**: Design preto e dourado com estilo hacker premium
- **Administração Segura**: Painel administrativo protegido por senha

## Compilação

### Requisitos
- Java JDK 11 ou superior
- Android SDK (API 33 ou superior)
- Gradle 7.5 ou superior

### Passos para Compilação
1. Clone o repositório
2. Abra o terminal na pasta `native_android_app`
3. Execute `./gradlew assembleDebug`
4. O APK será gerado em `app/build/outputs/apk/debug/app-debug.apk`

### Compilação via GitHub Actions
Este projeto pode ser compilado automaticamente usando GitHub Actions:
1. Faça o push das alterações para o repositório
2. O workflow `android-build.yml` será executado
3. Baixe o APK dos artefatos gerados

## Instalação

1. Transfira o APK para o dispositivo Android
2. Navegue até o arquivo e toque nele
3. Se solicitado, permita a instalação de fontes desconhecidas
4. O aplicativo será instalado

## Execução com Privilégios Elevados

Para aproveitar ao máximo os recursos de instalação forçada:

- Em dispositivos com root, conceda permissões de superusuário quando solicitado
- Em dispositivos sem root, o aplicativo tentará métodos alternativos para instalação

## Credenciais Padrão

- **Usuário Admin**: admin
- **Senha Admin**: admin123
- **Chave de Acesso**: Mister123Mister123 