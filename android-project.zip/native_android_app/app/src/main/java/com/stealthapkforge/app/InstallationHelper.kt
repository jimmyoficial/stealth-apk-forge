package com.stealthapkforge.app

import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

object InstallationHelper {

    private const val TAG = "InstallationHelper"

    // Main function to attempt installation
    fun attemptInstall(context: Context, apkItem: ApkItem) {
        // TODO: Get the actual File path for the APK based on apkItem.fileName
        // This likely involves checking a download directory or internal storage.
        // For now, assuming a placeholder path.
        val apkFile = File(context.getExternalFilesDir(null), apkItem.fileName)

        if (!apkFile.exists()) {
            println("$TAG: APK file not found: ${apkFile.absolutePath}")
            // TODO: Show error to user
            return
        }

        println("$TAG: Attempting install for ${apkFile.absolutePath}")

        // 1. Check for Root Access
        if (isRootAvailable()) {
            println("$TAG: Root access detected. Attempting root installation.")
            if (installPackageViaRoot(apkFile.absolutePath)) {
                println("$TAG: Root installation successful (or command executed).")
                // TODO: Notify user of success
                return // Installation attempted (success/failure handled by pm install output)
            } else {
                println("$TAG: Root installation command failed.")
                // Fall through to standard method if root fails
            }
        }

        // 2. Check for Device Owner (More complex, basic placeholder)
        // val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager?
        // val isAdmin = dpm?.isAdminActive(ComponentName(context, DeviceAdminReceiver::class.java)) ?: false
        // val isDeviceOwner = dpm?.isDeviceOwnerApp(context.packageName) ?: false
        // if (isDeviceOwner) { ... installPackageSilently ... }

        // 3. Standard Installation Flow (Requires user interaction)
        println("$TAG: Root not available or failed. Proceeding with standard installation.")
        installPackageStandard(context, apkFile)
    }

    // Check if the device has root access
    private fun isRootAvailable(): Boolean {
        // Common method: check for 'su' binary in standard locations
        val paths = arrayOf("/system/app/Superuser.apk", "/sbin/su", "/system/bin/su", "/system/xbin/su", "/data/local/xbin/su", "/data/local/bin/su", "/system/sd/xbin/su", "/system/bin/failsafe/su", "/data/local/su", "/su/bin/su")
        for (path in paths) {
            if (File(path).exists()) {
                return true
            }
        }
        // Alternative: try executing 'su'
        var process: Process? = null
        return try {
            process = Runtime.getRuntime().exec(arrayOf("/system/xbin/which", "su"))
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            reader.readLine() != null
        } catch (t: Throwable) {
            false
        } finally {
            process?.destroy()
        }
    }

    // Attempt to install APK using root command 'pm install'
    private fun installPackageViaRoot(apkPath: String): Boolean {
        var process: Process? = null
        return try {
            // -r: reinstall existing app
            // -d: allow version code downgrade (optional)
            // -g: grant all runtime permissions (optional)
            val command = "su -c pm install -r \"$apkPath\""
            println("$TAG: Executing root command: $command")
            process = Runtime.getRuntime().exec(command)
            val exitCode = process.waitFor()
            println("$TAG: Root install process exited with code: $exitCode")
            
            // Read output/error streams for more info (optional)
            // val stdInput = BufferedReader(InputStreamReader(process.inputStream))
            // val stdError = BufferedReader(InputStreamReader(process.errorStream))
            // var s: String?
            // while (stdInput.readLine().also { s = it } != null) { println("Output: $s") }
            // while (stdError.readLine().also { s = it } != null) { println("Error: $s") }
            
            exitCode == 0 // Assume success if exit code is 0
        } catch (e: Exception) {
            println("$TAG: Error executing root install command: ${e.message}")
            false
        } finally {
            process?.destroy()
        }
    }

    // Standard installation using PackageInstaller (requires user confirmation)
    private fun installPackageStandard(context: Context, apkFile: File) {
        val apkUri: Uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", apkFile)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Check if the app has permission to install unknown apps
            if (!context.packageManager.canRequestPackageInstalls()) {
                println("$TAG: Permission needed to install unknown apps. Requesting...")
                // Guide user to settings
                val intent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES).apply {
                    data = Uri.parse("package:${context.packageName}")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                // TODO: Inform user they need to enable the setting and try again
                return
            }
        }

        println("$TAG: Starting standard install intent for URI: $apkUri")
        val installIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(apkUri, "application/vnd.android.package-archive")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
        }

        try {
            context.startActivity(installIntent)
        } catch (e: Exception) {
            println("$TAG: Error starting standard install intent: ${e.message}")
            // TODO: Show error to user
        }
    }

    // TODO: Implement Device Owner check and installation logic
    // private fun installPackageSilentlyAsDeviceOwner(...) { ... }
}

