package com.stealthapkforge.app

// Data class to hold information about an APK file
data class ApkItem(
    val id: String,
    val name: String,
    val version: String?,
    val fileSize: String?,
    val description: String?,
    val uploadedBy: String,
    val iconUrl: String?, // URL or path to the icon
    val fileName: String // The actual file name for installation/download
    // Add status (pending, approved) if needed for admin view
    // val status: String = "approved" 
)

