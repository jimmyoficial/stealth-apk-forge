package com.stealthapkforge.app

import android.content.Context
import android.content.SharedPreferences

class CredentialsManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("StealthAppPrefs", Context.MODE_PRIVATE)

    companion object {
        private const val ADMIN_USERNAME_KEY = "admin_username"
        private const val ADMIN_PASSWORD_KEY = "admin_password"
        private const val ACCESS_KEY_KEY = "access_key"
        private const val SAVED_ACCESS_KEY = "saved_access_key" // Key to store the user-entered valid key

        // Default values (as per requirements)
        private const val DEFAULT_ADMIN_USERNAME = "admin"
        private const val DEFAULT_ADMIN_PASSWORD = "admin123"
        private const val DEFAULT_ACCESS_KEY = "Mister123Mister123" // The master key
    }

    fun initializeIfNeeded() {
        if (!prefs.contains(ADMIN_USERNAME_KEY)) {
            prefs.edit().putString(ADMIN_USERNAME_KEY, DEFAULT_ADMIN_USERNAME).apply()
        }
        if (!prefs.contains(ADMIN_PASSWORD_KEY)) {
            prefs.edit().putString(ADMIN_PASSWORD_KEY, DEFAULT_ADMIN_PASSWORD).apply()
        }
        // The DEFAULT_ACCESS_KEY is not stored directly, it's used for verification
    }

    fun verifyAdminCredentials(username: String, password: String): Boolean {
        val storedUsername = prefs.getString(ADMIN_USERNAME_KEY, DEFAULT_ADMIN_USERNAME)
        val storedPassword = prefs.getString(ADMIN_PASSWORD_KEY, DEFAULT_ADMIN_PASSWORD)
        return username == storedUsername && password == storedPassword
    }

    fun changeAdminPassword(newPassword: String) {
        prefs.edit().putString(ADMIN_PASSWORD_KEY, newPassword).apply()
    }

    // Checks if the user has successfully entered a valid access key before
    fun isAccessKeySet(): Boolean {
        return prefs.contains(SAVED_ACCESS_KEY)
    }

    // Verifies the entered key against the master key
    fun verifyAccessKey(enteredKey: String): Boolean {
        // In a real scenario, this might involve a server call or more complex logic
        return enteredKey == DEFAULT_ACCESS_KEY
    }

    // Saves the valid key entered by the user
    fun saveAccessKey(key: String) {
        prefs.edit().putString(SAVED_ACCESS_KEY, key).apply()
    }

    // Resets the saved access key, forcing the user to enter it again
    fun resetSavedAccessKey() {
        prefs.edit().remove(SAVED_ACCESS_KEY).apply()
    }

    // This function resets the MASTER access key. 
    // In this simple SharedPreferences implementation, we can't truly "reset" the hardcoded
    // DEFAULT_ACCESS_KEY. This function simulates it by clearing the SAVED key,
    // effectively forcing re-entry on next launch. A real implementation would likely
    // involve a backend or a more complex local storage mechanism.
    fun resetMasterAccessKey() {
        println("Simulating Master Access Key Reset by clearing saved key.")
        resetSavedAccessKey()
        // If the master key was stored in prefs (not recommended for hardcoded values),
        // you would update it here.
        // prefs.edit().putString(ACCESS_KEY_KEY, newMasterKey).apply()
    }
}

