package com.stealthapkforge.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.stealthapkforge.app.databinding.ListItemApkBinding // Assuming ViewBinding

class ApkListAdapter(
    private val apkList: MutableList<ApkItem>,
    private val onInstallClick: (ApkItem) -> Unit // Lambda for install button click
) : RecyclerView.Adapter<ApkListAdapter.ApkViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ApkViewHolder {
        val binding = ListItemApkBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ApkViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ApkViewHolder, position: Int) {
        val apkItem = apkList[position]
        holder.bind(apkItem)
    }

    override fun getItemCount(): Int = apkList.size

    fun updateData(newApkList: List<ApkItem>) {
        apkList.clear()
        apkList.addAll(newApkList)
        notifyDataSetChanged() // In a real app, use DiffUtil for better performance
    }

    inner class ApkViewHolder(private val binding: ListItemApkBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(apkItem: ApkItem) {
            binding.apkName.text = apkItem.name
            binding.apkVersionSize.text = "v${apkItem.version ?: "N/A"} • ${apkItem.fileSize ?: "N/A"}"
            binding.apkUploader.text = "${binding.root.context.getString(R.string.by_user_prefix)} ${apkItem.uploadedBy}"

            if (!apkItem.description.isNullOrEmpty()) {
                binding.apkDescription.text = apkItem.description
                binding.apkDescription.visibility = View.VISIBLE
            } else {
                binding.apkDescription.visibility = View.GONE
            }

            // TODO: Load icon using a library like Glide or Coil if apkItem.iconUrl is available
            // binding.apkIcon.setImageResource(R.drawable.placeholder_icon) // Placeholder

            binding.installButton.setOnClickListener {
                onInstallClick(apkItem)
            }
        }
    }
}

