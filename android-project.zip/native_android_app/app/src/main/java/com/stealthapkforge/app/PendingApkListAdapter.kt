package com.stealthapkforge.app

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.stealthapkforge.app.databinding.ListItemPendingApkBinding // Assuming ViewBinding

class PendingApkListAdapter(
    private val pendingApkList: MutableList<ApkItem>,
    private val onApproveClick: (ApkItem) -> Unit,
    private val onRejectClick: (ApkItem) -> Unit
) : RecyclerView.Adapter<PendingApkListAdapter.PendingApkViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PendingApkViewHolder {
        val binding = ListItemPendingApkBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PendingApkViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PendingApkViewHolder, position: Int) {
        val apkItem = pendingApkList[position]
        holder.bind(apkItem)
    }

    override fun getItemCount(): Int = pendingApkList.size

    fun updateData(newPendingApkList: List<ApkItem>) {
        pendingApkList.clear()
        pendingApkList.addAll(newPendingApkList)
        notifyDataSetChanged() // Use DiffUtil for better performance in a real app
    }

    inner class PendingApkViewHolder(private val binding: ListItemPendingApkBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(apkItem: ApkItem) {
            binding.pendingApkName.text = apkItem.name
            binding.pendingApkUploader.text = "Enviado por: ${apkItem.uploadedBy}"

            // TODO: Load icon if available
            // binding.pendingApkIcon.setImageResource(R.drawable.placeholder_icon)

            binding.approveButton.setOnClickListener {
                onApproveClick(apkItem)
            }

            binding.rejectButton.setOnClickListener {
                onRejectClick(apkItem)
            }
        }
    }
}

