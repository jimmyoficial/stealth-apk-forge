package com.stealthapkforge.app

import android.app.AlertDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.stealthapkforge.app.databinding.ActivityMainBinding
import com.stealthapkforge.app.databinding.DialogAdminLoginBinding // Import binding for dialog

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var apkListAdapter: ApkListAdapter
    // Placeholder for data persistence (replace with actual implementation)
    private val credentialsManager = CredentialsManager(this)
    private val apkDataManager = ApkDataManager(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)

        setupRecyclerView()
        setupFab()
        setupLogoLongClickListener()

        // Initialize data if needed (first launch)
        credentialsManager.initializeIfNeeded()
        apkDataManager.initializeIfNeeded()

        loadApks()
        checkAccessKey()
    }

    private fun setupRecyclerView() {
        apkListAdapter = ApkListAdapter(mutableListOf()) { apkItem ->
            initiateInstallation(apkItem)
        }
        binding.apkRecyclerView.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = apkListAdapter
        }
    }

    private fun setupFab() {
        binding.fabAddApk.setOnClickListener {
            showAddApkDialog()
        }
    }

    private fun setupLogoLongClickListener() {
        binding.logoPlaceholder.setOnLongClickListener {
            showAdminLoginDialog()
            true
        }
    }

    private fun loadApks() {
        // Load approved APKs from data source
        val approvedApks = apkDataManager.getApprovedApks()
        apkListAdapter.updateData(approvedApks)
    }

    private fun initiateInstallation(apkItem: ApkItem) {
        println("Initiating installation for: ${apkItem.name} with file ${apkItem.fileName}")
        InstallationHelper.attemptInstall(this, apkItem)
        // TODO: Handle results/feedback from InstallationHelper (e.g., show toasts)
        // Consider using ActivityResultLauncher for ACTION_MANAGE_UNKNOWN_APP_SOURCES
        // and ACTION_VIEW install intents to get results.
        Toast.makeText(this, "Iniciando instalação de ${apkItem.name}...", Toast.LENGTH_SHORT).show()
    }

    private fun showAddApkDialog() {
        // Placeholder: Implement Add APK UI (e.g., another Activity or DialogFragment)
        println("Show Add APK dialog")
        Toast.makeText(this, "Funcionalidade de Upload (WIP)", Toast.LENGTH_SHORT).show()
    }

    private fun showAdminLoginDialog() {
        val dialogBinding = DialogAdminLoginBinding.inflate(LayoutInflater.from(this))
        val dialog = AlertDialog.Builder(this, R.style.Theme_StealthApkForge_Dialog) // Use a custom dialog theme if needed
            .setView(dialogBinding.root)
            .create()

        dialogBinding.adminLoginButton.setOnClickListener {
            val username = dialogBinding.adminUsernameInput.text.toString()
            val password = dialogBinding.adminPasswordInput.text.toString()

            if (credentialsManager.verifyAdminCredentials(username, password)) {
                Toast.makeText(this, "Login Admin bem-sucedido!", Toast.LENGTH_SHORT).show()
                // Navigate to AdminActivity
                startActivity(Intent(this, AdminActivity::class.java))
                dialog.dismiss()
            } else {
                Toast.makeText(this, "Credenciais inválidas!", Toast.LENGTH_SHORT).show()
            }
        }
        dialog.show()
    }

    private fun checkAccessKey() {
        if (!credentialsManager.isAccessKeySet()) {
            showAccessKeyDialog()
        }
    }

    private fun showAccessKeyDialog() {
        val input = EditText(this).apply {
            setTextColor(resources.getColor(R.color.stealth_gold_light, theme))
            setHintTextColor(resources.getColor(R.color.stealth_grey, theme))
            hint = getString(R.string.access_key_prompt)
        }

        AlertDialog.Builder(this, R.style.Theme_StealthApkForge_Dialog)
            .setTitle("Chave de Acesso Necessária")
            .setView(input)
            .setCancelable(false) // Prevent dismissing without entering key
            .setPositiveButton("Verificar") { _, _ ->
                val enteredKey = input.text.toString()
                if (credentialsManager.verifyAccessKey(enteredKey)) {
                    credentialsManager.saveAccessKey(enteredKey) // Save the valid key
                    Toast.makeText(this, "Chave de acesso válida!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Chave inválida! Tente novamente.", Toast.LENGTH_LONG).show()
                    // Re-show the dialog or handle invalid key scenario
                    showAccessKeyDialog() 
                }
            }
            .show()
    }
}

// Placeholder for a custom dialog theme (add to themes.xml if needed)
/*
<style name="Theme.StealthApkForge.Dialog" parent="Theme.MaterialComponents.DayNight.Dialog.Alert">
    <item name="android:background">@color/stealth_black</item>
    <item name="colorAccent">@color/stealth_gold</item>
    <item name="android:textColorPrimary">@color/stealth_gold_light</item>
    <item name="android:textColorSecondary">@color/stealth_grey</item>
    <item name="buttonBarPositiveButtonStyle">@style/StealthDialogButton</item>
    <item name="buttonBarNegativeButtonStyle">@style/StealthDialogButton</item>
</style>

<style name="StealthDialogButton" parent="Widget.MaterialComponents.Button.TextButton.Dialog">
    <item name="android:textColor">@color/stealth_gold</item>
</style>
*/

