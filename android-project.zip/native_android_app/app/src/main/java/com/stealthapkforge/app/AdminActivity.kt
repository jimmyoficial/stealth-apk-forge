package com.stealthapkforge.app

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import com.stealthapkforge.app.databinding.ActivityAdminBinding
import com.stealthapkforge.app.databinding.DialogChangePasswordBinding // Need to create this layout

class AdminActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAdminBinding
    private lateinit var pendingApkListAdapter: PendingApkListAdapter
    private val apkDataManager = ApkDataManager(this)
    private val credentialsManager = CredentialsManager(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAdminBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.adminToolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true) // Add back button
        supportActionBar?.setDisplayShowHomeEnabled(true)

        setupRecyclerView()
        setupAdminActions()

        loadPendingApks()
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }

    private fun setupRecyclerView() {
        pendingApkListAdapter = PendingApkListAdapter(
            mutableListOf(),
            onApproveClick = { apkItem ->
                apkDataManager.approveApk(apkItem.id)
                Toast.makeText(this, "${apkItem.name} aprovado!", Toast.LENGTH_SHORT).show()
                loadPendingApks() // Refresh list
            },
            onRejectClick = { apkItem ->
                apkDataManager.rejectApk(apkItem.id)
                Toast.makeText(this, "${apkItem.name} rejeitado!", Toast.LENGTH_SHORT).show()
                loadPendingApks() // Refresh list
            }
        )
        binding.pendingApkRecyclerView.apply {
            layoutManager = LinearLayoutManager(this@AdminActivity)
            adapter = pendingApkListAdapter
        }
    }

    private fun setupAdminActions() {
        binding.resetKeyButton.setOnClickListener {
            // Show confirmation dialog before resetting
            AlertDialog.Builder(this, R.style.Theme_StealthApkForge_Dialog)
                .setTitle("Confirmar Reset")
                .setMessage("Tem certeza que deseja resetar a chave de acesso mestre? Isso forçará todos os usuários a inseri-la novamente.")
                .setPositiveButton("Resetar") { _, _ ->
                    credentialsManager.resetMasterAccessKey()
                    Toast.makeText(this, "Chave de acesso resetada!", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }

        binding.changePasswordButton.setOnClickListener {
            showChangePasswordDialog()
        }
    }

    private fun loadPendingApks() {
        val pendingApks = apkDataManager.getPendingApks()
        pendingApkListAdapter.updateData(pendingApks)
    }

    private fun showChangePasswordDialog() {
        // Need to create layout dialog_change_password.xml
        val dialogBinding = DialogChangePasswordBinding.inflate(layoutInflater)
        val dialog = AlertDialog.Builder(this, R.style.Theme_StealthApkForge_Dialog)
            .setView(dialogBinding.root)
            .setTitle("Alterar Senha Admin")
            .setPositiveButton("Salvar") { _, _ ->
                val newPassword = dialogBinding.newPasswordInput.text.toString()
                val confirmPassword = dialogBinding.confirmPasswordInput.text.toString()
                if (newPassword.isNotEmpty() && newPassword == confirmPassword) {
                    credentialsManager.changeAdminPassword(newPassword)
                    Toast.makeText(this, "Senha alterada com sucesso!", Toast.LENGTH_SHORT).show()
                } else if (newPassword.isEmpty()) {
                    Toast.makeText(this, "Senha não pode ser vazia!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Senhas não conferem!", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancelar", null)
            .create()
        dialog.show()
    }
}

