package com.stealthapkforge.app

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class ApkDataManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("StealthAppPrefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    companion object {
        private const val APKS_LIST_KEY = "apks_list"

        // Initial sample APKs (as per requirements, assuming files exist)
        private val initialApks = listOf(
            ApkItem(
                id = "1",
                name = "TikTok Pro",
                uploadedBy = "Sistema",
                // dateUploaded = Use current time on creation if needed
                // status = "approved", // Status will be handled by list separation
                fileSize = "45.3 MB",
                version = "1.2.3",
                description = "Versão aprimorada com recursos adicionais",
                iconUrl = null, // Placeholder
                fileName = "TikTok_Pro_v1.2.3.apk" // IMPORTANT: Ensure this file exists where InstallationHelper expects it
            ),
            ApkItem(
                id = "2",
                name = "Instagram Mod",
                uploadedBy = "Sistema",
                fileSize = "38.7 MB",
                version = "2.0.1",
                description = "Versão modificada com recursos premium",
                iconUrl = null, // Placeholder
                fileName = "Instagram_Mod_v2.0.1.apk" // IMPORTANT: Ensure this file exists
            )
        )
    }

    fun initializeIfNeeded() {
        if (!prefs.contains(APKS_LIST_KEY)) {
            // Store initial APKs as approved
            val initialData = mapOf("approved" to initialApks, "pending" to emptyList<ApkItem>())
            saveAllData(initialData)
        }
    }

    private fun loadAllData(): Map<String, List<ApkItem>> {
        val json = prefs.getString(APKS_LIST_KEY, null)
        return if (json != null) {
            val type = object : TypeToken<Map<String, List<ApkItem>>>() {}.type
            try {
                gson.fromJson(json, type)
            } catch (e: Exception) {
                // Handle potential deserialization errors
                println("Error loading APK data: ${e.message}")
                mapOf("approved" to emptyList(), "pending" to emptyList())
            }
        } else {
            mapOf("approved" to emptyList(), "pending" to emptyList())
        }
    }

    private fun saveAllData(data: Map<String, List<ApkItem>>) {
        val json = gson.toJson(data)
        prefs.edit().putString(APKS_LIST_KEY, json).apply()
    }

    fun getApprovedApks(): List<ApkItem> {
        return loadAllData()["approved"] ?: emptyList()
    }

    fun getPendingApks(): List<ApkItem> {
        return loadAllData()["pending"] ?: emptyList()
    }

    // Note: This adds to the pending list. Real file upload needs separate handling.
    fun addPendingApk(name: String, uploader: String, version: String?, fileSize: String?, description: String?, fileName: String) {
        val allData = loadAllData().toMutableMap()
        val pendingList = (allData["pending"] ?: emptyList()).toMutableList()
        
        val newApk = ApkItem(
            id = System.currentTimeMillis().toString(), // Simple unique ID
            name = name,
            uploadedBy = uploader,
            version = version,
            fileSize = fileSize,
            description = description,
            iconUrl = null, // Placeholder
            fileName = fileName
        )
        
        pendingList.add(newApk)
        allData["pending"] = pendingList
        saveAllData(allData)
    }

    fun approveApk(apkId: String) {
        val allData = loadAllData().toMutableMap()
        val pendingList = (allData["pending"] ?: emptyList()).toMutableList()
        val approvedList = (allData["approved"] ?: emptyList()).toMutableList()

        val apkToApprove = pendingList.find { it.id == apkId }
        if (apkToApprove != null) {
            pendingList.remove(apkToApprove)
            approvedList.add(apkToApprove) // Add to approved list
            allData["pending"] = pendingList
            allData["approved"] = approvedList
            saveAllData(allData)
        }
    }

    fun rejectApk(apkId: String) {
        val allData = loadAllData().toMutableMap()
        val pendingList = (allData["pending"] ?: emptyList()).toMutableList()

        val removed = pendingList.removeIf { it.id == apkId }
        if (removed) {
            allData["pending"] = pendingList
            saveAllData(allData)
            // Optionally, delete the associated file if it was uploaded
        }
    }
}

